package com.allobank.rocket.model;

import java.math.BigDecimal;

public record Rocket(
    String id,
    String name,
    String description,
    String imageUrl,
    BigDecimal launchCost,
    String country,
    String firstFlight,
    boolean local
) {}
