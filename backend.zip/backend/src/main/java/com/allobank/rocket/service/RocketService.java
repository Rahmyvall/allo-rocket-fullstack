package com.allobank.rocket.service;

import com.allobank.rocket.dto.CreateRocketRequest;
import com.allobank.rocket.model.Rocket;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RocketService {
    private static final String API_BASE = "https://lldev.thespacedevs.com/2.2.0";
    private final WebClient client = WebClient.builder().baseUrl(API_BASE).build();
    private final Map<String, Rocket> localRockets = new ConcurrentHashMap<>();

    public List<Rocket> getAll() {
        Map<String, Object> response = client.get()
            .uri(uri -> uri.path("/config/launcher/")
                .queryParam("manufacturer__name", "SpaceX")
                .queryParam("mode", "detailed")
                .queryParam("limit", 20).build())
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
            .block();

        List<Rocket> rockets = new ArrayList<>();
        if (response != null && response.get("results") instanceof List<?> results) {
            for (Object item : results) {
                if (item instanceof Map<?, ?> raw) {
                    Map<String, Object> map = (Map<String, Object>) raw;
                    rockets.add(fromApi(map));
                }
            }
        }
        rockets.addAll(localRockets.values());
        return rockets;
    }

    public Rocket getById(String id) {
        Rocket local = localRockets.get(id);
        if (local != null) return local;

        Map<String, Object> map = client.get()
            .uri("/config/launcher/{id}/", id)
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
            .block();
        if (map == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Rocket not found");
        return fromApi(map);
    }

    public Rocket create(CreateRocketRequest request) {
        String id = "rocket-local-" + UUID.randomUUID();
        Rocket rocket = new Rocket(id, request.name(), request.description(), request.imageUrl(),
            request.launchCost(), request.country(), request.firstFlight(), true);
        localRockets.put(id, rocket);
        return rocket;
    }

    private Rocket fromApi(Map<String, Object> map) {
        String id = String.valueOf(map.getOrDefault("id", ""));
        String name = stringValue(map.get("full_name"));
        String description = stringValue(map.get("description"));
        String imageUrl = stringValue(map.get("image_url"));
        Object cost = map.get("launch_cost");
        java.math.BigDecimal launchCost = null;
        if (cost != null) {
            try { launchCost = new java.math.BigDecimal(cost.toString()); }
            catch (NumberFormatException ignored) { /* keep missing/invalid cost as null */ }
        }
        String country = null;
        Object manufacturer = map.get("manufacturer");
        if (manufacturer instanceof Map<?, ?> m) country = stringValue(m.get("country_code"));
        String firstFlight = stringValue(map.get("maiden_flight"));
        return new Rocket(id, name, description, imageUrl, launchCost, country, firstFlight, false);
    }

    private String stringValue(Object value) {
        return value == null ? null : value.toString();
    }
}
