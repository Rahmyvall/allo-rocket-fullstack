package com.allobank.rocket.controller;

import com.allobank.rocket.dto.CreateRocketRequest;
import com.allobank.rocket.model.Rocket;
import com.allobank.rocket.service.RocketService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rockets")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class RocketController {
    private final RocketService service;

    public RocketController(RocketService service) {
        this.service = service;
    }

    @GetMapping
    public List<Rocket> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Rocket getById(@PathVariable String id) {
        return service.getById(id);
    }

    @PostMapping
    public Rocket create(@Valid @RequestBody CreateRocketRequest request) {
        return service.create(request);
    }
}
