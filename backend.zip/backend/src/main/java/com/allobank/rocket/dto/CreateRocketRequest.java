package com.allobank.rocket.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

public record CreateRocketRequest(
    @NotBlank @Size(max = 120) String name,
    @Size(max = 2000) String description,
    String imageUrl,
    BigDecimal launchCost,
    String country,
    String firstFlight
) {}
