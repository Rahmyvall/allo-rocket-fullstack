package com.allobank.rocket;

import com.allobank.rocket.controller.RocketController;
import com.allobank.rocket.dto.CreateRocketRequest;
import com.allobank.rocket.model.Rocket;
import com.allobank.rocket.service.RocketService;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class RocketControllerTest {
    @Test
    void createRocketReturnsLocalRocket() throws Exception {
        RocketService service = mock(RocketService.class);
        Rocket rocket = new Rocket("rocket-local-1", "Demo Rocket", "Demo", null, null, "ID", null, true);
        when(service.create(any(CreateRocketRequest.class))).thenReturn(rocket);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(new RocketController(service)).build();

        mvc.perform(post("/api/rockets")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Demo Rocket\",\"description\":\"Demo\",\"country\":\"ID\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.name").value("Demo Rocket"))
            .andExpect(jsonPath("$.local").value(true));
    }
}
